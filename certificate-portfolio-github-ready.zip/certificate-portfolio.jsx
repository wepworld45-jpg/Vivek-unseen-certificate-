import React, { useMemo, useState } from "react";
import {
  Award, BookOpen, Briefcase, CheckCircle2, ChevronRight,
  ExternalLink, GraduationCap, Menu, Search, Sparkles, X
} from "lucide-react";

const certificates = [
  { id: 1, title: "Professional Development", issuer: "Certificate of Achievement", category: "Professional", year: "2025", icon: Briefcase, description: "Professional development and career-focused learning achievement.", image: "/certificates/certificate-01.jpg" },
  { id: 2, title: "Digital Skills", issuer: "Certificate of Completion", category: "Skills", year: "2025", icon: Sparkles, description: "Recognition for developing practical digital and technology skills.", image: "/certificates/certificate-02.jpg" },
  { id: 3, title: "Academic Achievement", issuer: "Educational Certificate", category: "Education", year: "2025", icon: GraduationCap, description: "Academic learning achievement and continued educational development.", image: "/certificates/certificate-03.jpg" },
  { id: 4, title: "Business & Management", issuer: "Certificate of Completion", category: "Professional", year: "2025", icon: Briefcase, description: "Learning focused on business, management and professional capabilities.", image: "/certificates/certificate-04.jpg" },
  { id: 5, title: "Learning & Growth", issuer: "Certificate of Participation", category: "Education", year: "2025", icon: BookOpen, description: "Participation in continuous learning and personal development.", image: "/certificates/certificate-05.jpg" },
  { id: 6, title: "Wellness & Awareness", issuer: "Certificate of Participation", category: "Wellness", year: "2025", icon: CheckCircle2, description: "Recognition for participation in wellness and awareness initiatives.", image: "/certificates/certificate-06.jpg" }
];

const categories = ["All", "Professional", "Skills", "Education", "Wellness"];

export default function CertificatePortfolio() {
  const [activeCategory, setActiveCategory] = useState("All");
  const [selectedCertificate, setSelectedCertificate] = useState(null);
  const [search, setSearch] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);

  const filteredCertificates = useMemo(() => certificates.filter(c => {
    const categoryMatch = activeCategory === "All" || c.category === activeCategory;
    const q = search.toLowerCase();
    const searchMatch = c.title.toLowerCase().includes(q) || c.category.toLowerCase().includes(q) || c.issuer.toLowerCase().includes(q);
    return categoryMatch && searchMatch;
  }), [activeCategory, search]);

  return (
    <div className="app">
      <style>{styles}</style>

      <header className="navbar">
        <div className="nav-inner">
          <a href="#" className="logo"><span className="logo-mark">V</span><span>Vivek Tiwari</span></a>
          <nav className={`nav-links ${menuOpen ? "open" : ""}`}>
            <a href="#home" onClick={() => setMenuOpen(false)}>Home</a>
            <a href="#certificates" onClick={() => setMenuOpen(false)}>Certificates</a>
            <a href="#about" onClick={() => setMenuOpen(false)}>About</a>
          </nav>
          <button className="menu-button" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu">
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </header>

      <main>
        <section className="hero" id="home">
          <div className="hero-glow glow-one" />
          <div className="hero-glow glow-two" />
          <div className="hero-content">
            <div className="eyebrow"><Award size={15} /> CERTIFICATE PORTFOLIO</div>
            <h1>Learning today.<br /><span>Building tomorrow.</span></h1>
            <p>A curated collection of professional certifications, educational achievements, skills and continuous learning.</p>
            <div className="hero-actions">
              <a href="#certificates" className="primary-button">Explore Certificates <ChevronRight size={18} /></a>
              <a href="#about" className="secondary-button">About Me</a>
            </div>
          </div>
          <div className="hero-stats">
            <div><strong>{certificates.length}+</strong><span>Certificates</span></div>
            <div><strong>4</strong><span>Categories</span></div>
            <div><strong>2025</strong><span>Latest Year</span></div>
          </div>
        </section>

        <section className="section" id="certificates">
          <div className="section-heading">
            <div>
              <span className="section-label">MY ACHIEVEMENTS</span>
              <h2>Certificates & Credentials</h2>
              <p>Explore the milestones that represent my learning journey.</p>
            </div>
          </div>

          <div className="toolbar">
            <div className="search-box">
              <Search size={18} />
              <input type="text" placeholder="Search certificates..." value={search} onChange={e => setSearch(e.target.value)} />
            </div>
            <div className="filters">
              {categories.map(category => (
                <button key={category} className={activeCategory === category ? "filter active" : "filter"} onClick={() => setActiveCategory(category)}>
                  {category}
                </button>
              ))}
            </div>
          </div>

          <div className="certificate-grid">
            {filteredCertificates.map(certificate => {
              const Icon = certificate.icon;
              return (
                <article className="certificate-card" key={certificate.id}>
                  <div className="certificate-image">
                    <img src={certificate.image} alt={certificate.title} />
                    <div className="image-overlay">
                      <button onClick={() => setSelectedCertificate(certificate)}>View Certificate <ExternalLink size={16} /></button>
                    </div>
                  </div>
                  <div className="certificate-content">
                    <div className="certificate-icon"><Icon size={19} /></div>
                    <div className="certificate-meta"><span>{certificate.category}</span><span>{certificate.year}</span></div>
                    <h3>{certificate.title}</h3>
                    <p>{certificate.description}</p>
                    <button className="view-button" onClick={() => setSelectedCertificate(certificate)}>View details <ChevronRight size={16} /></button>
                  </div>
                </article>
              );
            })}
          </div>

          {filteredCertificates.length === 0 && (
            <div className="empty"><Search size={32} /><h3>No certificates found</h3><p>Try another search or category.</p></div>
          )}
        </section>

        <section className="about-section" id="about">
          <div className="about-card">
            <div className="about-icon"><Sparkles size={28} /></div>
            <div>
              <span className="section-label">CONTINUOUS GROWTH</span>
              <h2>More than certificates.</h2>
              <p>Every certificate represents a step in a larger journey — learning new skills, exploring new ideas and continuously improving.</p>
            </div>
          </div>
        </section>
      </main>

      <footer>
        <div><strong>Vivek Tiwari</strong><span>Certificate Portfolio</span></div>
        <span>© 2025 · Built with React</span>
      </footer>

      {selectedCertificate && (
        <div className="modal-backdrop" onClick={() => setSelectedCertificate(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <button className="close-modal" onClick={() => setSelectedCertificate(null)}><X size={20} /></button>
            <img src={selectedCertificate.image} alt={selectedCertificate.title} />
            <div className="modal-content">
              <span>{selectedCertificate.category}</span>
              <h2>{selectedCertificate.title}</h2>
              <p>{selectedCertificate.description}</p>
              <div className="modal-info">
                <div><small>Issuer</small><strong>{selectedCertificate.issuer}</strong></div>
                <div><small>Year</small><strong>{selectedCertificate.year}</strong></div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const styles = `
:root{--bg:#08090d;--surface:#101219;--border:rgba(255,255,255,.09);--text:#f5f7fa;--muted:#969ba8}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:var(--bg);color:var(--text)}button,input{font:inherit}a{color:inherit;text-decoration:none}
.app{min-height:100vh;background:radial-gradient(circle at 80% 10%,rgba(112,82,255,.1),transparent 30%),var(--bg)}
.navbar{position:sticky;top:0;z-index:50;backdrop-filter:blur(20px);background:rgba(8,9,13,.78);border-bottom:1px solid var(--border)}
.nav-inner{max-width:1180px;margin:auto;padding:16px 22px;display:flex;align-items:center;justify-content:space-between}
.logo{display:flex;align-items:center;gap:10px;font-weight:750}.logo-mark{width:34px;height:34px;border-radius:10px;display:grid;place-items:center;background:linear-gradient(135deg,#9b7cff,#57d5ff);font-weight:900}
.nav-links{display:flex;gap:30px;color:var(--muted);font-size:14px}.nav-links a:hover{color:white}.menu-button{display:none;background:transparent;color:white}
.hero{max-width:1180px;margin:auto;min-height:680px;padding:110px 22px 70px;position:relative;display:flex;flex-direction:column;justify-content:center}
.hero-content{max-width:760px;position:relative;z-index:2}.eyebrow,.section-label{color:#a995ff;font-size:12px;letter-spacing:.16em;font-weight:800}.eyebrow{display:flex;gap:8px;align-items:center;margin-bottom:22px}
.hero h1{font-size:clamp(48px,8vw,88px);line-height:.98;letter-spacing:-.055em;margin:0}.hero h1 span{background:linear-gradient(90deg,#a78bfa,#59d9ff);-webkit-background-clip:text;color:transparent}
.hero p{color:var(--muted);max-width:610px;font-size:18px;line-height:1.7;margin:28px 0}.hero-actions{display:flex;gap:12px;flex-wrap:wrap}
.primary-button,.secondary-button{min-height:48px;padding:0 20px;border-radius:12px;display:inline-flex;align-items:center;gap:8px;font-weight:700;transition:.25s ease}.primary-button{background:white;color:#08090d}.secondary-button{border:1px solid var(--border)}
.hero-stats{margin-top:90px;display:flex;gap:60px;position:relative;z-index:2}.hero-stats div{display:flex;flex-direction:column;gap:5px}.hero-stats strong{font-size:28px}.hero-stats span{color:var(--muted);font-size:13px}
.hero-glow{position:absolute;border-radius:50%;filter:blur(80px);pointer-events:none}.glow-one{width:300px;height:300px;right:5%;top:15%;background:rgba(123,92,255,.18)}.glow-two{width:200px;height:200px;right:25%;bottom:10%;background:rgba(60,200,255,.1)}
.section{max-width:1180px;margin:auto;padding:80px 22px}.section-heading{margin-bottom:38px}.section-heading h2,.about-card h2{font-size:clamp(30px,5vw,48px);letter-spacing:-.04em;margin:10px 0}.section-heading p{color:var(--muted)}
.toolbar{display:flex;gap:15px;justify-content:space-between;align-items:center;margin-bottom:30px;flex-wrap:wrap}.search-box{display:flex;align-items:center;gap:9px;padding:12px 15px;background:var(--surface);border:1px solid var(--border);border-radius:12px;color:var(--muted)}.search-box input{width:210px;outline:none;border:0;background:transparent;color:white}.filters{display:flex;gap:7px;overflow-x:auto}.filter{white-space:nowrap;padding:9px 13px;border-radius:9px;background:transparent;border:1px solid var(--border);color:var(--muted);cursor:pointer}.filter.active{background:white;color:#08090d}
.certificate-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}.certificate-card{background:linear-gradient(145deg,rgba(255,255,255,.065),rgba(255,255,255,.025));border:1px solid var(--border);border-radius:18px;overflow:hidden;transition:.3s}.certificate-card:hover{transform:translateY(-5px);border-color:rgba(167,139,250,.35)}
.certificate-image{height:205px;position:relative;overflow:hidden}.certificate-image img{width:100%;height:100%;object-fit:cover;transition:.5s}.certificate-card:hover img{transform:scale(1.06)}
.image-overlay{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.55);opacity:0;transition:.3s}.certificate-card:hover .image-overlay{opacity:1}.image-overlay button{padding:11px 14px;border-radius:10px;display:flex;gap:7px;align-items:center;cursor:pointer}
.certificate-content{padding:20px}.certificate-icon{width:40px;height:40px;border-radius:11px;display:grid;place-items:center;background:rgba(155,124,255,.12);color:#b7a3ff;margin-bottom:17px}.certificate-meta{display:flex;justify-content:space-between;color:var(--muted);font-size:11px;text-transform:uppercase;letter-spacing:.08em}.certificate-content h3{margin:10px 0;font-size:20px}.certificate-content p{color:var(--muted);line-height:1.6;font-size:14px;min-height:66px}.view-button{background:transparent;color:white;display:flex;align-items:center;gap:5px;padding:0;cursor:pointer;font-weight:700}
.about-section{max-width:1180px;margin:auto;padding:20px 22px 100px}.about-card{padding:45px;display:flex;gap:25px;align-items:flex-start;border:1px solid var(--border);border-radius:22px;background:radial-gradient(circle at 90% 0%,rgba(87,213,255,.08),transparent 35%),var(--surface)}.about-icon{min-width:58px;height:58px;display:grid;place-items:center;border-radius:15px;background:rgba(155,124,255,.13);color:#b7a3ff}.about-card p{color:var(--muted);max-width:650px;line-height:1.8}
footer{border-top:1px solid var(--border);max-width:1180px;margin:auto;padding:28px 22px;display:flex;justify-content:space-between;gap:20px;color:var(--muted);font-size:13px}footer div{display:flex;gap:8px;flex-direction:column}footer strong{color:white}
.modal-backdrop{position:fixed;inset:0;z-index:100;background:rgba(0,0,0,.78);backdrop-filter:blur(12px);display:grid;place-items:center;padding:20px}.modal{max-width:850px;width:100%;max-height:90vh;overflow:auto;background:#11131a;border:1px solid var(--border);border-radius:20px;position:relative}.modal>img{width:100%;max-height:450px;object-fit:cover}.close-modal{position:absolute;top:14px;right:14px;z-index:2;width:38px;height:38px;display:grid;place-items:center;border-radius:50%;background:rgba(0,0,0,.65);color:white;cursor:pointer}.modal-content{padding:25px}.modal-content>span{color:#a995ff;font-size:12px;text-transform:uppercase;letter-spacing:.1em}.modal-content h2{font-size:30px;margin:8px 0}.modal-content p{color:var(--muted);line-height:1.7}.modal-info{display:flex;gap:50px;margin-top:25px}.modal-info div{display:flex;flex-direction:column;gap:5px}.modal-info small{color:var(--muted)}
.empty{text-align:center;padding:80px 20px;color:var(--muted)}.empty h3{color:white}
@media(max-width:850px){.certificate-grid{grid-template-columns:repeat(2,1fr)}.nav-links{display:none}.menu-button{display:block}.nav-links.open{position:absolute;top:67px;left:0;right:0;display:flex;flex-direction:column;padding:20px;background:#0d0f14;border-bottom:1px solid var(--border)}}
@media(max-width:600px){.hero{min-height:620px;padding-top:80px}.hero h1{font-size:49px}.hero p{font-size:16px}.hero-stats{margin-top:65px;gap:25px}.hero-stats strong{font-size:23px}.certificate-grid{grid-template-columns:1fr}.certificate-image{height:220px}.search-box{width:100%}.search-box input{width:100%}.filters{width:100%;padding-bottom:3px}.about-card{padding:28px;flex-direction:column}footer{flex-direction:column}.modal-info{gap:25px}}
`;

