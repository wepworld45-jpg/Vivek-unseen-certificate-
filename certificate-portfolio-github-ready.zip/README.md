# 📜 Vivek Tiwari - Certificate Portfolio

A modern, mobile-first React certificate portfolio.

## Features

- Mobile-first responsive design
- Certificate categories
- Search and filtering
- Interactive certificate viewer
- Smooth UI interactions
- Dark premium visual style
- Local certificate image support

## Project structure

```text
certificate-portfolio/
├── README.md
├── certificate-portfolio.jsx
├── index.html
├── index.js
├── package.json
└── certificates/
    ├── certificate-01.jpg
    ├── certificate-02.jpg
    ├── certificate-03.jpg
    ├── certificate-04.jpg
    ├── certificate-05.jpg
    └── certificate-06.jpg
```

## Add your certificates

Upload your certificate images into the `certificates` folder and keep the filenames above, or edit the image paths in `certificate-portfolio.jsx`.

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```
