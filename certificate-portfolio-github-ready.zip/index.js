import React from "react";
import ReactDOM from "react-dom/client";
import CertificatePortfolio from "./certificate-portfolio.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <CertificatePortfolio />
  </React.StrictMode>
);